export enum PlayerActionType {
  READY = "ready",
  SUBMIT = "submit",
  USE_ITEM = "use-item"
}
export class LeaderboardController {
  public static updatePlayerScore() {

  }
}
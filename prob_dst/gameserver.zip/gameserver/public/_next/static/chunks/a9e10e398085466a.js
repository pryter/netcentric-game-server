__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/871ab61f5e45de2e.js",
  "static/chunks/turbopack-730952d6b9212bcd.js"
])
